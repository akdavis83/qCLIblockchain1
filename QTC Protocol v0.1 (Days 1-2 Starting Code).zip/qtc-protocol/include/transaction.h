#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include "consensus.h"

namespace qtc {

// Reference to a previous transaction output
struct OutPoint {
    std::vector<uint8_t> txid;   // 32-byte transaction ID
    uint32_t vout = 0;           // output index

    bool is_null() const { return txid.empty(); }
    std::vector<uint8_t> serialize() const;
};

// Transaction input
struct TxInput {
    OutPoint prevout;
    std::vector<uint8_t> script;    // unlocking script / witness data
    uint32_t sequence = 0xffffffff;

    std::vector<uint8_t> serialize() const;
};

// Transaction output
struct TxOutput {
    uint64_t amount = 0;             // in satoshis
    std::vector<uint8_t> script;     // locking script / address commitment

    std::vector<uint8_t> serialize() const;
};

// QTC Transaction v1
//
// PQ witness structure (modular, for Day 5 integration):
//   - algorithm_id (1 byte): SigAlgorithm enum
//   - public_key (variable): Dilithium3 public key (1952 bytes)
//   - signature (variable): Dilithium3 signature (up to 3293 bytes)
//
struct Transaction {
    uint32_t version = TX_VERSION;
    std::vector<TxInput> inputs;
    std::vector<TxOutput> outputs;
    uint32_t locktime = 0;

    // PQ witness data (placeholder for Day 5)
    uint8_t sig_algorithm_id = 0;  // 0 = unsigned (placeholder)
    std::vector<uint8_t> public_key;
    std::vector<uint8_t> signature;

    // Serialize the full transaction (for txid computation)
    std::vector<uint8_t> serialize() const;

    // Compute transaction ID (double SHA-256 of serialized tx)
    std::vector<uint8_t> txid() const;
    std::string txid_hex() const;

    // Check if this is a coinbase transaction
    bool is_coinbase() const;

    // Create a genesis coinbase transaction with a given message
    static Transaction create_genesis_coinbase(const std::string& message, uint64_t reward);
};

} // namespace qtc
