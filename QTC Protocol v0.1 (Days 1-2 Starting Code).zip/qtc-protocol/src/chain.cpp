#include "chain.h"
#include "crypto.h"
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace qtc {

Chain::Chain() : network_(Network::REGTEST), initialized_(false) {}

void Chain::init(Network network) {
    if (initialized_) return;
    
    network_ = network;
    
    Block genesis;
    switch (network) {
        case Network::REGTEST:
            genesis = Block::create_regtest_genesis();
            break;
        // MAINNET and TESTNET genesis will be frozen later
        default:
            genesis = Block::create_regtest_genesis();
            break;
    }
    
    blocks_.clear();
    blocks_.push_back(genesis);
    initialized_ = true;
}

Chain::BlockchainInfo Chain::get_blockchain_info() const {
    BlockchainInfo info;
    info.network = network_;
    info.height = static_cast<uint32_t>(blocks_.size()) - 1;
    info.best_block_hash = blocks_.empty() ? "" : blocks_.back().header.hash_hex();
    info.difficulty_bits = blocks_.empty() ? 0 : blocks_.back().header.difficulty_bits;
    info.chain_work = 0;  // TODO: implement cumulative work
    info.initialized = initialized_;
    return info;
}

const Block& Chain::get_block(uint32_t height) const {
    if (height >= blocks_.size()) {
        throw std::out_of_range("Block height " + std::to_string(height) + " out of range");
    }
    return blocks_[height];
}

const Block& Chain::get_genesis() const {
    if (blocks_.empty()) {
        throw std::runtime_error("Chain not initialized");
    }
    return blocks_[0];
}

bool Chain::add_block(const Block& block) {
    if (blocks_.empty()) {
        return false;
    }
    
    // Validate: previous hash must match current tip
    const auto& tip = blocks_.back();
    auto tip_hash = tip.header.hash();
    
    // Check previous hash linkage
    if (block.header.prev_block_hash.size() != 32 || tip_hash.size() != 32) {
        return false;
    }
    for (size_t i = 0; i < 32; ++i) {
        if (block.header.prev_block_hash[i] != tip_hash[i]) {
            std::cerr << "Block rejected: previous hash mismatch\n";
            return false;
        }
    }
    
    // Check merkle root
    auto computed_root = block.compute_merkle_root();
    if (computed_root.size() != 32 || block.header.merkle_root.size() != 32) {
        return false;
    }
    for (size_t i = 0; i < 32; ++i) {
        if (block.header.merkle_root[i] != computed_root[i]) {
            std::cerr << "Block rejected: merkle root mismatch\n";
            return false;
        }
    }
    
    // Check PoW
    if (!block.validate_pow()) {
        std::cerr << "Block rejected: PoW invalid\n";
        return false;
    }
    
    blocks_.push_back(block);
    return true;
}

bool Chain::validate_chain() const {
    if (blocks_.empty()) return false;
    
    // Validate genesis
    if (!blocks_[0].validate_pow()) {
        std::cerr << "Genesis block PoW invalid" << std::endl;
        return false;
    }
    
    // Validate each block links to the previous one
    for (size_t i = 1; i < blocks_.size(); ++i) {
        const auto& prev = blocks_[i - 1];
        const auto& curr = blocks_[i];
        
        // Check previous hash linkage
        auto prev_hash = prev.header.hash();
        for (size_t j = 0; j < 32 && j < curr.header.prev_block_hash.size(); ++j) {
            if (curr.header.prev_block_hash[j] != prev_hash[j]) {
                std::cerr << "Block " << i << ": previous hash mismatch" << std::endl;
                return false;
            }
        }
        
        // Check PoW
        if (!curr.validate_pow()) {
            std::cerr << "Block " << i << ": PoW invalid" << std::endl;
            return false;
        }
        
        // Check merkle root
        auto computed_root = curr.compute_merkle_root();
        for (size_t j = 0; j < 32 && j < curr.header.merkle_root.size(); ++j) {
            if (curr.header.merkle_root[j] != computed_root[j]) {
                std::cerr << "Block " << i << ": merkle root mismatch" << std::endl;
                return false;
            }
        }
    }
    
    return true;
}

bool Chain::save(const std::string& filepath) const {
    // Development save: write chain state as a simple text file
    // Production will use a proper database
    std::ofstream out(filepath);
    if (!out) return false;
    
    out << "# QTC Chain State (development format)" << std::endl;
    out << "network=" << static_cast<int>(network_) << std::endl;
    out << "height=" << (blocks_.size() - 1) << std::endl;
    
    for (size_t i = 0; i < blocks_.size(); ++i) {
        out << "block_" << i << "_hash=" << blocks_[i].header.hash_hex() << std::endl;
        out << "block_" << i << "_timestamp=" << blocks_[i].header.timestamp << std::endl;
        out << "block_" << i << "_nonce=" << blocks_[i].header.nonce << std::endl;
        out << "block_" << i << "_txcount=" << blocks_[i].transactions.size() << std::endl;
    }
    
    return true;
}

bool Chain::load(const std::string& filepath) {
    // Development load: reconstruct from saved state
    // For now, just re-init from genesis
    // Full persistence will come in Phase 9
    std::ifstream in(filepath);
    if (!in) return false;
    
    // TODO: Implement full chain loading
    // For now, re-create genesis
    init(network_);
    return true;
}

} // namespace qtc
