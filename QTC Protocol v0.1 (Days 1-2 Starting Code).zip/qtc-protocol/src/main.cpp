#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include "chain.h"
#include "block.h"
#include "transaction.h"
#include "crypto.h"
#include "consensus.h"

namespace qtc {

static const char* network_name(Network net) {
    switch (net) {
        case Network::MAINNET: return "mainnet";
        case Network::TESTNET: return "testnet";
        case Network::REGTEST: return "regtest";
        default: return "unknown";
    }
}

static void print_usage() {
    std::cout
        << "QTC Protocol CLI v0.1\n"
        << "\n"
        << "Usage: qtc <command> [options]\n"
        << "\n"
        << "Commands:\n"
        << "  init                  Initialize QTC chain (regtest)\n"
        << "  getblockchaininfo      Display chain state\n"
        << "  getblock <height>      Display block at given height\n"
        << "  getblockhash <height>  Display block hash at given height\n"
        << "  selftest               Run internal self-tests\n"
        << "  help                   Show this help\n"
        << "\n"
        << "Future commands (not yet implemented):\n"
        << "  wallet <create|balance|send|listunspent>\n"
        << "  tx <create|sign|validate|broadcast>\n"
        << "  mine [n] [address]\n"
        << "  node <start|status|stop>\n";
}

static void print_block(const Block& block, uint32_t height) {
    std::string hash_str = block.header.hash_hex();  // hash_hex already handles LE reversal
    
    std::cout << "Block #" << height << "\n";
    std::cout << "  Version:          " << block.header.version << "\n";
    std::cout << "  Previous hash:    " << crypto::to_hex(block.header.prev_block_hash) << "\n";
    std::cout << "  Merkle root:      " << crypto::to_hex(block.header.merkle_root) << "\n";
    std::cout << "  Timestamp:        " << block.header.timestamp;
    
    // Format timestamp as UTC
    time_t ts = block.header.timestamp;
    char time_buf[64];
    struct tm* tm_info = gmtime(&ts);
    strftime(time_buf, sizeof(time_buf), "%Y-%m-%d %H:%M:%S UTC", tm_info);
    std::cout << " (" << time_buf << ")\n";
    
    std::cout << "  Difficulty bits:  0x" << std::hex << std::setfill('0') << std::setw(8)
              << block.header.difficulty_bits << std::dec << "\n";
    std::cout << "  Nonce:            " << block.header.nonce << "\n";
    std::cout << "  Block hash:       " << hash_str << "\n";
    std::cout << "  PoW valid:        " << (block.validate_pow() ? "YES" : "NO") << "\n";
    std::cout << "  Transactions:     " << block.transactions.size() << "\n";
    
    for (size_t i = 0; i < block.transactions.size(); ++i) {
        const auto& tx = block.transactions[i];
        std::cout << "    TX[" << i << "]: " << tx.txid_hex() << "\n";
        std::cout << "      Inputs:  " << tx.inputs.size() << "\n";
        std::cout << "      Outputs: " << tx.outputs.size() << "\n";
        std::cout << "      Coinbase: " << (tx.is_coinbase() ? "YES" : "NO") << "\n";
        if (tx.is_coinbase() && !tx.inputs.empty() && !tx.inputs[0].script.empty()) {
            // Extract message from coinbase script
            std::string message;
            for (size_t j = 1; j < tx.inputs[0].script.size(); ++j) {
                char c = static_cast<char>(tx.inputs[0].script[j]);
                if (c >= 32 && c < 127) message += c;
            }
            if (!message.empty()) {
                std::cout << "      Message: " << message << "\n";
            }
        }
        for (size_t j = 0; j < tx.outputs.size(); ++j) {
            double amount_qtc = static_cast<double>(tx.outputs[j].amount) / static_cast<double>(COIN);
            std::cout << "      Output[" << j << "]: " << std::fixed << std::setprecision(8)
                      << amount_qtc << " QTC\n";
        }
    }
}

static int run_selftest() {
    int passed = 0;
    int failed = 0;
    
    auto check = [&](const std::string& name, bool condition) {
        if (condition) {
            std::cout << "[PASS] " << name << "\n";
            passed++;
        } else {
            std::cout << "[FAIL] " << name << "\n";
            failed++;
        }
    };
    
    std::cout << "=== QTC Self-Test ===\n\n";
    
    // 1. SHA-256 known answer test
    {
        auto hash = crypto::sha256(std::vector<uint8_t>{'a', 'b', 'c'});
        std::string hex = crypto::to_hex(hash);
        // SHA-256("abc") = ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad
        check("SHA-256 known answer (abc)", hex == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    }
    
    // 2. Double SHA-256
    {
        auto hash = crypto::double_sha256(std::vector<uint8_t>{'a', 'b', 'c'});
        // Should be 32 bytes
        check("Double SHA-256 produces 32 bytes", hash.size() == 32);
    }
    
    // 3. Hex round-trip
    {
        std::vector<uint8_t> original = {0x00, 0x01, 0x02, 0xFF, 0xAB, 0xCD};
        std::string hex = crypto::to_hex(original);
        auto decoded = crypto::from_hex(hex);
        check("Hex round-trip", original == decoded);
    }
    
    // 4. LE serialization round-trip
    {
        uint32_t val = 0x12345678;
        auto bytes = crypto::write_le_u32(val);
        uint32_t recovered = crypto::read_le_u32(bytes.data());
        check("LE u32 round-trip", val == recovered);
    }
    
    // 5. Genesis block determinism
    {
        Block g1 = Block::create_regtest_genesis();
        Block g2 = Block::create_regtest_genesis();
        check("Genesis block is deterministic", g1.header.hash_hex() == g2.header.hash_hex());
    }
    
    // 6. Genesis PoW validity
    {
        Block genesis = Block::create_regtest_genesis();
        check("Genesis block PoW is valid", genesis.validate_pow());
    }
    
    // 7. Genesis has coinbase
    {
        Block genesis = Block::create_regtest_genesis();
        bool has_coinbase = !genesis.transactions.empty() && genesis.transactions[0].is_coinbase();
        check("Genesis block has coinbase", has_coinbase);
    }
    
    // 8. Coinbase amount
    {
        Block genesis = Block::create_regtest_genesis();
        check("Genesis coinbase reward is 50 QTC",
              genesis.transactions[0].outputs[0].amount == INITIAL_SUBSIDY);
    }
    
    // 9. Merkle root computation
    {
        Block genesis = Block::create_regtest_genesis();
        auto computed = genesis.compute_merkle_root();
        bool matches = (computed.size() == 32);
        for (size_t i = 0; i < 32 && i < genesis.header.merkle_root.size(); ++i) {
            if (computed[i] != genesis.header.merkle_root[i]) {
                matches = false;
                break;
            }
        }
        check("Genesis merkle root matches computed root", matches);
    }
    
    // 10. Chain initialization
    {
        Chain chain;
        chain.init(Network::REGTEST);
        auto info = chain.get_blockchain_info();
        check("Chain initializes with height 0", info.height == 0);
        check("Chain reports as initialized", info.initialized);
        check("Chain is regtest", info.network == Network::REGTEST);
    }
    
    // 11. Transaction serialization round-trip (basic)
    {
        Transaction tx = Transaction::create_genesis_coinbase("TEST", 50 * COIN);
        auto serialized = tx.serialize();
        check("Genesis coinbase serializes to non-empty", !serialized.empty());
        check("Genesis coinbase txid is 32 bytes", tx.txid().size() == 32);
    }
    
    // 12. Block header is 80 bytes
    {
        Block genesis = Block::create_regtest_genesis();
        auto header_bytes = genesis.header.serialize();
        check("Block header is exactly 80 bytes", header_bytes.size() == 80);
    }
    
    std::cout << "\n";
    std::cout << "QTC Self-Test: " << passed << " passed, " << failed << " failed\n";
    if (failed == 0) {
        std::cout << "QTC Self-Test: ALL PASS\n";
    }
    
    return failed;
}

} // namespace qtc

int main(int argc, char* argv[]) {
    if (argc < 2) {
        qtc::print_usage();
        return 0;
    }
    
    std::string command = argv[1];
    
    if (command == "help" || command == "--help" || command == "-h") {
        qtc::print_usage();
        return 0;
    }
    
    if (command == "init") {
        qtc::Chain chain;
        chain.init(qtc::Network::REGTEST);
        auto info = chain.get_blockchain_info();
        
        std::cout << "QTC chain initialized.\n";
        std::cout << "Network: " << qtc::network_name(info.network) << "\n";
        std::cout << "Height: " << info.height << "\n";
        std::cout << "Genesis hash: " << info.best_block_hash << "\n";
        std::cout << "Difficulty bits: 0x" << std::hex << info.difficulty_bits << std::dec << "\n";
        
        // Save chain state
        chain.save("data/chain_state.txt");
        std::cout << "Chain state saved to data/chain_state.txt\n";
        return 0;
    }
    
    if (command == "getblockchaininfo") {
        qtc::Chain chain;
        chain.init(qtc::Network::REGTEST);
        
        auto info = chain.get_blockchain_info();
        std::cout << "{\n";
        std::cout << "  \"network\": \"" << qtc::network_name(info.network) << "\",\n";
        std::cout << "  \"height\": " << info.height << ",\n";
        std::cout << "  \"best_block_hash\": \"" << info.best_block_hash << "\",\n";
        std::cout << "  \"difficulty_bits\": " << info.difficulty_bits << ",\n";
        std::cout << "  \"initialized\": " << (info.initialized ? "true" : "false") << "\n";
        std::cout << "}\n";
        return 0;
    }
    
    if (command == "getblock") {
        if (argc < 3) {
            std::cerr << "Usage: qtc getblock <height>\n";
            return 1;
        }
        
        uint32_t height = static_cast<uint32_t>(std::stoul(argv[2]));
        qtc::Chain chain;
        chain.init(qtc::Network::REGTEST);
        
        try {
            const auto& block = chain.get_block(height);
            qtc::print_block(block, height);
        } catch (const std::exception& e) {
            std::cerr << "Error: " << e.what() << "\n";
            return 1;
        }
        return 0;
    }
    
    if (command == "getblockhash") {
        if (argc < 3) {
            std::cerr << "Usage: qtc getblockhash <height>\n";
            return 1;
        }
        
        uint32_t height = static_cast<uint32_t>(std::stoul(argv[2]));
        qtc::Chain chain;
        chain.init(qtc::Network::REGTEST);
        
        try {
            const auto& block = chain.get_block(height);
            std::cout << block.header.hash_hex() << "\n";
        } catch (const std::exception& e) {
            std::cerr << "Error: " << e.what() << "\n";
            return 1;
        }
        return 0;
    }
    
    if (command == "selftest") {
        return qtc::run_selftest();
    }
    
    if (command == "validatechain") {
        qtc::Chain chain;
        chain.init(qtc::Network::REGTEST);
        
        if (chain.validate_chain()) {
            std::cout << "Chain validation: PASSED\n";
            return 0;
        } else {
            std::cout << "Chain validation: FAILED\n";
            return 1;
        }
    }
    
    std::cerr << "Unknown command: " << command << "\n";
    qtc::print_usage();
    return 1;
}
