#include "transaction.h"
#include "crypto.h"
#include "consensus.h"
#include <cstring>

namespace qtc {

// ============================================================
// OutPoint
// ============================================================

std::vector<uint8_t> OutPoint::serialize() const {
    // 32-byte txid + 4-byte vout (LE)
    std::vector<uint8_t> result;
    result.reserve(36);
    // Pad txid to 32 bytes if needed
    for (size_t i = 0; i < 32; ++i) {
        result.push_back(i < txid.size() ? txid[i] : 0);
    }
    auto vout_bytes = crypto::write_le_u32(vout);
    result.insert(result.end(), vout_bytes.begin(), vout_bytes.end());
    return result;
}

// ============================================================
// TxInput
// ============================================================

std::vector<uint8_t> TxInput::serialize() const {
    std::vector<uint8_t> result;
    // prevout (36 bytes)
    auto prevout_bytes = prevout.serialize();
    result.insert(result.end(), prevout_bytes.begin(), prevout_bytes.end());
    // script length (compact size — simplified: 1 byte if < 253)
    if (script.size() < 253) {
        result.push_back(static_cast<uint8_t>(script.size()));
    } else {
        result.push_back(0xFD);
        result.push_back(static_cast<uint8_t>(script.size() & 0xFF));
        result.push_back(static_cast<uint8_t>((script.size() >> 8) & 0xFF));
    }
    // script data
    result.insert(result.end(), script.begin(), script.end());
    // sequence (4 bytes LE)
    auto seq_bytes = crypto::write_le_u32(sequence);
    result.insert(result.end(), seq_bytes.begin(), seq_bytes.end());
    return result;
}

// ============================================================
// TxOutput
// ============================================================

std::vector<uint8_t> TxOutput::serialize() const {
    std::vector<uint8_t> result;
    // amount (8 bytes LE)
    auto amount_bytes = crypto::write_le_u64(amount);
    result.insert(result.end(), amount_bytes.begin(), amount_bytes.end());
    // script length
    if (script.size() < 253) {
        result.push_back(static_cast<uint8_t>(script.size()));
    } else {
        result.push_back(0xFD);
        result.push_back(static_cast<uint8_t>(script.size() & 0xFF));
        result.push_back(static_cast<uint8_t>((script.size() >> 8) & 0xFF));
    }
    // script data
    result.insert(result.end(), script.begin(), script.end());
    return result;
}

// ============================================================
// Transaction
// ============================================================

std::vector<uint8_t> Transaction::serialize() const {
    std::vector<uint8_t> result;
    
    // Version (4 bytes LE)
    auto version_bytes = crypto::write_le_u32(version);
    result.insert(result.end(), version_bytes.begin(), version_bytes.end());
    
    // Input count (compact size)
    if (inputs.size() < 253) {
        result.push_back(static_cast<uint8_t>(inputs.size()));
    } else {
        result.push_back(0xFD);
        result.push_back(static_cast<uint8_t>(inputs.size() & 0xFF));
        result.push_back(static_cast<uint8_t>((inputs.size() >> 8) & 0xFF));
    }
    
    // Inputs
    for (const auto& input : inputs) {
        auto input_bytes = input.serialize();
        result.insert(result.end(), input_bytes.begin(), input_bytes.end());
    }
    
    // Output count
    if (outputs.size() < 253) {
        result.push_back(static_cast<uint8_t>(outputs.size()));
    } else {
        result.push_back(0xFD);
        result.push_back(static_cast<uint8_t>(outputs.size() & 0xFF));
        result.push_back(static_cast<uint8_t>((outputs.size() >> 8) & 0xFF));
    }
    
    // Outputs
    for (const auto& output : outputs) {
        auto output_bytes = output.serialize();
        result.insert(result.end(), output_bytes.begin(), output_bytes.end());
    }
    
    // Locktime (4 bytes LE)
    auto locktime_bytes = crypto::write_le_u32(locktime);
    result.insert(result.end(), locktime_bytes.begin(), locktime_bytes.end());
    
    // PQ witness data (appended after locktime for v1)
    // TODO Day 5: public_key length and signature length need 2-byte encoding
    // to hold ML-DSA-65 sizes (1952-byte pubkey, up to 3293-byte signature).
    // Current 1-byte length fields will overflow. Not used until Day 5.
    if (sig_algorithm_id != 0) {
        result.push_back(sig_algorithm_id);
        result.push_back(static_cast<uint8_t>(public_key.size()));
        result.insert(result.end(), public_key.begin(), public_key.end());
        result.push_back(static_cast<uint8_t>(signature.size() & 0xFF));
        result.push_back(static_cast<uint8_t>((signature.size() >> 8) & 0xFF));
        result.insert(result.end(), signature.begin(), signature.end());
    }
    
    return result;
}

std::vector<uint8_t> Transaction::txid() const {
    return crypto::double_sha256(serialize());
}

std::string Transaction::txid_hex() const {
    return crypto::to_hex(txid());
}

bool Transaction::is_coinbase() const {
    if (inputs.size() != 1) return false;
    const auto& prevout = inputs[0].prevout;
    // Coinbase: null txid (all zeros) + vout = 0xffffffff
    if (prevout.vout != 0xffffffff) return false;
    if (prevout.txid.size() != 32) return true;  // treat empty as null
    for (uint8_t b : prevout.txid) {
        if (b != 0) return false;
    }
    return true;
}

Transaction Transaction::create_genesis_coinbase(const std::string& message, uint64_t reward) {
    Transaction tx;
    tx.version = TX_VERSION;
    
    // Coinbase input: null outpoint
    TxInput input;
    input.prevout.txid = std::vector<uint8_t>(32, 0);  // all zeros
    input.prevout.vout = 0xffffffff;
    
    // Encode height in the coinbase script (BIP34-style, but simplified)
    // Script: [height as varint] [message as ASCII]
    std::vector<uint8_t> script;
    // Height 0 as a single byte
    script.push_back(0x00);
    // Message
    for (char c : message) {
        script.push_back(static_cast<uint8_t>(c));
    }
    input.script = script;
    input.sequence = 0xffffffff;
    tx.inputs.push_back(input);
    
    // Output: reward to a null address commitment (will be replaced with real address)
    TxOutput output;
    output.amount = reward;
    // Placeholder script: OP_TRUE (just allows spending — for genesis only)
    output.script = {0x51};  // OP_1 = OP_TRUE
    tx.outputs.push_back(output);
    
    return tx;
}

} // namespace qtc
